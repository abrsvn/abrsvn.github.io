import re, string, subprocess, time
#LSAT_sentences = open('/Users/roberthenderson/Desktop/pos_chunking_script/tokenized_LSAT', 'r')
LSAT_sentences = open('./LSAT_min', 'r')
LSAT_lines = LSAT_sentences.readlines()
LSAT_sentences.close()

combinedList = []
toTag = []
tags = []

p = re.compile('&.*#')

for lines in LSAT_lines:
	strings = string.split(lines)
	tagList = []
	wordList = []
	for words in strings:
		matches = p.search(words)
		if matches is None:
			tagList.append("")
		elif matches is not None:
			matches = matches.group() 
			tagList.append(matches)
	for words in strings:
		subs = p.sub('', words)
		wordList.append(subs)	
		sentenceReconstructed = " ".join(wordList)	
	tags.append(tagList)
	toTag.append(sentenceReconstructed)

LSAT_toTag = open('./LSAT_toTag', 'w')
for lines in toTag:
	LSAT_toTag.write(lines+'\n')
LSAT_toTag.close()
#print tags

subprocess.call("cd /Users/roberthenderson/Dropbox/Documents/work/corpus/stanford-postagger-full-2010-05-26/; java -mx300m -classpath stanford-postagger.jar edu.stanford.nlp.tagger.maxent.MaxentTagger -model models/left3words-wsj-0-18.tagger -tokenized -tagSeparator / -textFile /Users/roberthenderson/Desktop/pos_chunking_script/LSAT_toTag > /Users/roberthenderson/Desktop/pos_chunking_script/LSAT_tagged", shell=True)

LSAT_tagged = open('./LSAT_tagged', 'r')
LSAT_tagged_lines = LSAT_tagged.readlines()
LSAT_tagged.close()

doubleTagged = []

m=0
for lines in LSAT_tagged_lines:
	n=0
 	strings = string.split(lines)
 	wordList = []
 	for words in strings:
 		catWord = words+tags[m][n]
 		wordList.append(catWord)
 		sentenceReconstructed = " ".join(wordList)
		n = n+1
 	doubleTagged.append(sentenceReconstructed)
	m = m+1

LSAT_doubleTagged = open('./LSAT_doubleTagged', 'w')

for lines in doubleTagged:
	LSAT_doubleTagged.write(lines+'\n')

LSAT_doubleTagged.close()

subprocess.call("cd /Users/roberthenderson/Dropbox/Documents/work/corpus/NP\ Chunking/; ./chunker.sh < /Users/roberthenderson/Desktop/pos_chunking_script/LSAT_doubleTagged > /Users/roberthenderson/Desktop/pos_chunking_script/LSAT_tagged_and_chunked", shell=True)


